﻿$(document).ready(function () {
    $('#btnSaveUploadedfile').click(function () {
        if (window.FormData !== undefined) {

            var fileUpload = $("#fuUploadTextFile").get(0);
            var files = fileUpload.files;

            var fileData = new FormData();
            if ($("#facilityItems").val() == '0' || files.length == 0) {
                alert('Facility and File both are mandatory.');
                return;
            }
            for (var i = 0; i < files.length; i++) {
                fileData.append(files[i].name, files[i]);
            }
            // Adding one more key to FormData object  
            fileData.append('facilityid', $("#facilityItems").val());
            fileData.append('facilityname', $("#facilityItems option:selected").text());
            $.ajax({
                url: '/WorkQueue/UploadFiles',
                type: "POST",
                contentType: false, // Not to set any content header  
                processData: false, // Not to process data  
                data: fileData,
                success: function (result) {
                    alert(result.Message);
                    window.location.reload();
                },
                error: function (result) {
                    alert("Failed to Upload File");
                }
            });
        }
        else {
            alert("FormData is not supported.");
        }
    });
});

function CopyAnylizeCode(str)
{
    alert(str);
}