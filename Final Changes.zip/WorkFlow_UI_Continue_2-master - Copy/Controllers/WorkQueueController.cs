﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Mvc;
using WorkFlowPototype.Models;
using TrustedI10model.workflow;
using WorkFlowPototype.App_Code;
using Newtonsoft.Json;

namespace WorkFlowPototype.Controllers
{
	public class WorkQueueController : Controller
	{
		TrustedI10DataContext.App_Code.General objGeneral = new TrustedI10DataContext.App_Code.General();
		[HttpGet]
		public ActionResult workQueue_bk(int? selectedRowID)
		{

			ViewBag.Title = "workQueue [GET] ActionResult";


			List<TrustedI10model.workflow.m_workqeueOBJ> wqlst = new List<TrustedI10model.workflow.m_workqeueOBJ>();
			ViewBag.Message = "";

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					switch (user_obj.accessLevel)
					{
						case 5:
							ViewBag.page = "verification";
							break;
						case 10:
							ViewBag.page = "MRanalyze";
							break;
						default:
							// not sure where, yet.
							ViewBag.page = "MRanalyze";
							break;
					}



					wqlst = WorkFlowPototype.App_Code.dataConnect.getWorkQueue(user_obj.id, user_obj.databaseName);
					return View(wqlst);
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				ViewBag.Message = ex.Message;
				return View("Error");
			}
			return View(wqlst);
		}


		[HttpGet]
		public ActionResult workQueue(int? selectedRowID)
		{

			ViewBag.Title = "workQueue [GET] ActionResult";


			List<TrustedI10model.workflow.m_workqeueOBJ> wqlst = new List<TrustedI10model.workflow.m_workqeueOBJ>();
			ViewBag.Message = "";
			TempData["actionName"] = "";

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;



					switch (user_obj.accessLevel)
					{
						case 5:
							TempData["actionName"] = "verification";
							break;
						case 10:
							TempData["actionName"] = "MRanalyze";
							break;
						default:
							// not sure where, yet.
							TempData["actionName"] = "MRanalyze";
							break;
					}



					wqlst = WorkFlowPototype.App_Code.dataConnect.getWorkQueue(user_obj.id, user_obj.databaseName);
					return View(wqlst);
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				ViewBag.Message = ex.Message;
				return View("Error");
			}
			return View(wqlst);
		}

		[HttpGet]
		public ActionResult workQueueSelected(int? selectedRowID)
		{

			ViewBag.Title = "workQueue [POST] ActionResult";

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					string viewName = "";

					//----------------
					if (selectedRowID == null)
					{
						ViewBag.Message = "what happen to the selected ID?";
						return View("Error");
					}
					else
					{
						switch (user_obj.accessLevel)
						{
							case 5:
								viewName = "verification";
								break;
							default:
								viewName = "MRanalyze";     // MRanalyze action
								break;
						}
					}

					return RedirectToAction(viewName, "WorkQueue", new { selectedRowID = selectedRowID });
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				//throw ex;
				ViewBag.Message = ex.Message;
				return View("Error");
			}

		}

		[HttpGet]
		public ActionResult unassignWQ()
		{

			ViewBag.Title = "unassignWQ [GET] ActionResult";

			List<TrustedI10model.workflow.m_unassignWQobj> wqLst = new List<TrustedI10model.workflow.m_unassignWQobj>();


			unassignObj viewObj;
			unassignLst viewLst = new unassignLst();
			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					// getting list for dropdown
					if (user_obj.accessLevel == 10)
					{
						ViewBag.teamItems = WorkFlowPototype.App_Code.General.getTeamSelectListItem(user_obj.teamMembers, user_obj.firstname + " " + user_obj.lastname, user_obj.id.ToString(), false);
					}
					else
					{
						ViewBag.teamItems = WorkFlowPototype.App_Code.General.getTeamSelectListItem(user_obj.teamMembers, "", "", false);
					}

					ViewBag.facilityItems = WorkFlowPototype.App_Code.General.getFacilitySelectListItem(user_obj.facilities, "", "", false);

					wqLst = TrustedI10DataContext.App_Code.Biz.workQueue.getUnassignWQ(user_obj.id, user_obj.databaseName);


					// after all this work, I still can't get the check to work.
					// -------------
					foreach (TrustedI10model.workflow.m_unassignWQobj obj in wqLst)
					{
						viewObj = new unassignObj();
						viewObj.emrHdID = obj.emrHdID;
						viewObj.filename = obj.fileName;
						viewObj.facilityName = obj.facilityName;
						viewObj.uploaded_date = obj.uploaded;
						viewObj.whoUploaded = obj.whoUploaded;
						viewObj.status = obj.status;
						viewLst.wqLst.Add(viewObj);
					}
					// --------------

					//return View(wqVM);
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				ViewBag.Message = ex.Message;
				return View("Error");
			}
			// why it give me error if I return view in the try {}? But I can do it in ActionResult workQueue()?
			return View(viewLst);
		}

		[HttpPost]
		public ActionResult assignWQ(String[] emrHdIDs, FormCollection frmUnAssignWork)
		{

			ViewBag.Title = "assignWQ [POST] ActionResult";




			TrustedI10model.workflow.m_assignment obj = new TrustedI10model.workflow.m_assignment();
			// get the team member 

			// obj.assign2who=== get it from get the team member dropdown


			//////
			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

				//// get all the value of the checked.
				List<TrustedI10model.workflow.m_assignment> assignmentLst = new List<TrustedI10model.workflow.m_assignment>();
				if (emrHdIDs != null && emrHdIDs.Length > 0)
				{
					foreach (var id in emrHdIDs)
					{
						m_assignment assignment = new m_assignment();
						if (user_obj.accessLevel != 10)
						{
							if (!string.IsNullOrEmpty(frmUnAssignWork["Assing2TeamItems"]))
								assignment.assign2who = Convert.ToInt32(frmUnAssignWork["Assing2TeamItems"]);
							else
								assignment.assign2who = Convert.ToInt32(frmUnAssignWork["teamItems"]);
						}
						else
							assignment.assign2who = user_obj.id;
						assignment.emr_headerID = Convert.ToInt32(id);
						assignment.whoIsAssigning = user_obj.id;
						if (string.IsNullOrEmpty(frmUnAssignWork["hdnAssignedOrHold"]))
							assignment.status = "CQ";
						else if (!string.IsNullOrEmpty(frmUnAssignWork["hdnAssignedOrHold"]) && frmUnAssignWork["hdnAssignedOrHold"] == "A")
							assignment.status = "CQ";
						else
							assignment.status = "H";
						if (!string.IsNullOrEmpty(frmUnAssignWork["note"]))
							assignment.note = frmUnAssignWork["note"];
						else
							assignment.note = "";
						assignmentLst.Add(assignment);
					}
				}
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					WorkFlowPototype.App_Code.dataConnect.makingAssignment(assignmentLst, user_obj.databaseName);

				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				ViewBag.Message = ex.Message;
				return View("Error");
			}

			if (!string.IsNullOrEmpty(frmUnAssignWork["hdnAssignedOrHold"]))
				return RedirectToAction("DailyActivity");
			return RedirectToAction("unassignWQ");

		}

		[HttpGet]
		public ActionResult MRanalyze(int? selectedRowID, int? emrHeaderID)
		{
			ViewBag.Title = "MRanalyze [GET] ActionResult";


			// come from workqueue selected row
			if (selectedRowID != null)
			{
				emrHeaderID = selectedRowID;
			}
			// come from verfificate back button...
			else if (emrHeaderID != null)
			{
				selectedRowID = emrHeaderID;
			}
			else
			{
				// where are you from?
				if (ViewBag.emrHeaderID != null)
				{
					selectedRowID = ViewBag.emrHeaderID;
				}
			}

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

				if (user_obj != null)
				{

					ViewBag.emrHeaderID = emrHeaderID;
					TempData["emrHeaderID"] = emrHeaderID;

					if (emrHeaderID > 0)
					{
						TrustedI10model.workflow.m_emrHeader obj = new TrustedI10model.workflow.m_emrHeader();
						TrustedI10model.workflow.m_wholeEMR wholeEMR = new TrustedI10model.workflow.m_wholeEMR();

						//Models.m_wholeEMR wholeEMR = new Models.m_wholeEMR();

						List<TrustedI10model.lookup.m_id_descr> visitLst = new List<TrustedI10model.lookup.m_id_descr>();
						Models.inParam inparam = new Models.inParam();

						ViewBag.clientName = user_obj.clientName;
						ViewBag.userName = user_obj.firstname;
						ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
						ViewBag.userID = user_obj.id;
						ViewBag.accessLevel = user_obj.accessLevel;

						wholeEMR = WorkFlowPototype.App_Code.dataConnect.getWholeEMR(ViewBag.emrHeaderID, user_obj.databaseName);

						if (wholeEMR.headerRec != null)
						{
							ViewBag.visitItems = WorkFlowPototype.App_Code.dataConnect.getVisitSelectListItem(user_obj.databaseName, false);
							ViewBag.providerItems = WorkFlowPototype.App_Code.dataConnect.getProviderSelectListItem(user_obj.databaseName, false);

							// getting list for dropdown
							//wholeEMR.visitItems = WorkFlowPototype.App_Code.dataConnect.getVisitSelectListItem(user_obj.databaseName);
							//wholeEMR.providerItems = WorkFlowPototype.App_Code.dataConnect.getProviderSelectListItem(user_obj.databaseName);
							//wholeEMR.providerSelectLst = new SelectList(wholeEMR.providerItems, "Value", "Text");

							return View(wholeEMR);
						}
						else
						{
							ViewBag.Message = "Internal problem.  Missing EMR header record.";
							ViewBag.emrHeaderID = 0;
							return View("Error");
						}
					}
					else
					{
						ViewBag.Message = "We loss the ID";
						ViewBag.emrHeaderID = 0;
						return View("Error");
					}
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				ViewBag.Message = ex.Message;
				return View("Error");
			}

		}

		[HttpPost]
		public ActionResult MRanalyze(FormCollection frm, TrustedI10model.workflow.m_wholeEMR objWholeEMR, string submitButton, string emrHeaderID)
		{
			ViewBag.Title = "MRanalyze [POST] ActionResult";

			string controllerName = "WorkQueue";
			string viewName = "MRanalyze";

			TrustedI10model.workflow.m_assignment assignment = new TrustedI10model.workflow.m_assignment();
			// initilize so null value does not cause the blow up.
			assignment.assign2who = 0;
			assignment.emr_headerID = 0;
			assignment.eSignature = false;
			assignment.note = "";
			assignment.db = "";

			string[] allkeys = frm.AllKeys;
			string buttonClick = "";

			// data gathering
			foreach (string s in allkeys)
			{
				switch (s.ToLower())
				{
					case "submitbutton":
						buttonClick = frm[s.ToString()];
						break;

					case "emrheaderid":
						emrHeaderID = frm[s.ToString()];
						assignment.emr_headerID = Convert.ToInt32(emrHeaderID);
						break;
					case "note":
						assignment.note = frm[s.ToString()];

						// sql does not like quote
						assignment.note = assignment.note.Replace(@"""", "`");
						assignment.note = assignment.note.Replace("'", "`");

						break;
					case "providerdd":
						// I dont know how to get the provider dropdown value.  

						break;
				}
			}


			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

				if (user_obj != null)
				{

					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					assignment.db = user_obj.databaseName;
					assignment.whoIsAssigning = user_obj.id;

					if (emrHeaderID != "")
					{
						ViewBag.emrHeaderID = Convert.ToInt32(emrHeaderID);

						switch (buttonClick)
						{
							case "Re-load the codes":
								// call data harmony api
								// don't know the api, yet.
								break;
							case "Save":
								// build objects 
								// call WorkFlowPototype.App_Code.dataConnect.updateWholeMR()
								break;

							case "Check the Codes":
								// call api
								//WorkFlowPototype.App_Code.dataConnect.getEMResult
								break;

							case "Complete":

								/*
								 * How do I keep the model (TrustedI10model.workflow.m_wholeEMR) from the view or from get action?
								 * I need the same informaton on this page.
								 * for now, I'll just call the api again.
								 * */
								viewName = "verification";
								break;
							case "Forward to Manager":
								assignment.status = "CR";
								assignment.removeFromQueue = "Y";
								// call web api
								WorkFlowPototype.App_Code.dataConnect.updateStatus(assignment, user_obj.databaseName);
								viewName = "workQueue";
								break;
						}

						return RedirectToAction(viewName, controllerName, new { selectedRowID = emrHeaderID });
					}
					else
					{
						ViewBag.Message = "what happen to the ID in MRanalyze [post]?";
						return View("Error");
					}
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				//throw ex;

				ViewBag.Message = ex.Message;
				return View("Error");
			}

		}
		
		
		[HttpGet]
		public ActionResult verification(int? selectedRowID, int? emrHeaderID, bool? viewOnly)
		{
			ViewBag.Title = "verification [GET] ActionResult";

			// come from workqueue selected row
			if (selectedRowID != null)
			{
				emrHeaderID = selectedRowID;
			}
			else if (emrHeaderID != null)
			{
				selectedRowID = emrHeaderID;
			}

			// 
			if (viewOnly == null)
			{
				viewOnly = false;
			}

			if (selectedRowID != null || emrHeaderID != null)
			{
				ViewBag.emrHeaderID = selectedRowID;

				try
				{
					TrustedI10model.workflow.m_wholeEMR wholeEMR = new TrustedI10model.workflow.m_wholeEMR();
					TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
					if (user_obj != null)
					{
						ViewBag.clientName = user_obj.clientName;
						ViewBag.userName = user_obj.firstname;
						ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
						ViewBag.userID = user_obj.id;
						ViewBag.accessLevel = user_obj.accessLevel;
						ViewBag.viewOnly = true;
						ViewBag.emrHeaderID = emrHeaderID;

						wholeEMR = WorkFlowPototype.App_Code.dataConnect.getWholeEMR(ViewBag.emrHeaderID, user_obj.databaseName);
						if (wholeEMR.headerRec != null)
						{
							ViewBag.providerItems = WorkFlowPototype.App_Code.dataConnect.getProviderSelectListItem(user_obj.databaseName, false);
							return View(wholeEMR);
						}
						else
						{
							ViewBag.Message = "Internal problem.  Missing EMR header record.";
							return View("Error");
						}

					}

				}
				catch (Exception ex)
				{
					ViewBag.Message = ex.Message;
					return View("Error");
				}
			}
			else
			{
				ViewBag.Message = "Internal problem.  Missing EMR header record.";
				return View("Error");
			}

			return View();
		}

		[HttpPost]
		public ActionResult verification(FormCollection frm, TrustedI10model.workflow.m_wholeEMR model)
		{


			ViewBag.Title = "verification [POST] ActionResult";

			TrustedI10model.workflow.m_assignment assignment = new TrustedI10model.workflow.m_assignment();
			// initilize so null value does not cause the blow up.
			assignment.assign2who = 0;
			assignment.emr_headerID = 0;
			assignment.eSignature = false;
			assignment.note = "";
			assignment.db = "";

			int emrHeaderID = 0;
			string buttonClick = "";
			bool eSignture = false;

			string[] allkeys = frm.AllKeys;
			string keyValue = "";

			foreach (string s in allkeys)
			{
				switch (s.ToLower())
				{
					case "submitbutton":
						buttonClick = frm[s.ToString()];
						break;

					case "emrheaderid":
						keyValue = frm[s.ToString()];
						emrHeaderID = Convert.ToInt32(keyValue);
						assignment.emr_headerID = emrHeaderID;
						break;
					case "note":
						assignment.note = frm[s.ToString()];

						// sql does not like quote
						assignment.note = assignment.note.Replace(@"""", "`");
						assignment.note = assignment.note.Replace("'", "`");

						break;
					case "cbesignature":
						keyValue = frm[s.ToString()];  // 'on' if checked.  The key is not even in the list if not check
						eSignture = true;
						break;
					case "providerdd":
						// I dont know how to get the provider dropdown value.  

						break;
				}
			}

			// assignment.assign2who need to get the value from  provider dd
			// for testing, I'm going to stuff provider ID #7
			assignment.assign2who = 7;
			assignment.eSignature = eSignture;

			string controllerName = "WorkQueue";
			string viewName = "workQueue";
			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					assignment.db = user_obj.databaseName;
					assignment.whoIsAssigning = user_obj.id;

					// forward to provider
					// do assignment to provider here
					// back to work queue

					if (emrHeaderID > 0)
					{
						ViewBag.emrHeaderID = emrHeaderID;

						switch (buttonClick)
						{
							case "Forward to Provider":
								assignment.status = "PQ";
								assignment.removeFromQueue = "Y";
								// call web api
								WorkFlowPototype.App_Code.dataConnect.makingAssignment(assignment, user_obj.databaseName);

								break;

							case "Accept":
								assignment.status = "PA";
								assignment.removeFromQueue = "Y";
								// call web api
								WorkFlowPototype.App_Code.dataConnect.updateStatus(assignment, user_obj.databaseName);

								// need to do:
								// at this point, we need to create pdf file.

								break;
							case "Reject":
								assignment.status = "PR";
								assignment.removeFromQueue = "Y";
								// call web api
								WorkFlowPototype.App_Code.dataConnect.updateStatus(assignment, user_obj.databaseName);
								break;
							case "Go Back":

								if (user_obj.accessLevel != 5)
								{
									// not a provider, back to workqueue screen
									controllerName = "WorkQueue";
									viewName = "MRanalyze";

									//return RedirectToAction(viewName, controllerName);

									return RedirectToAction(viewName, controllerName, new { selectedRowID = emrHeaderID });
								}
								break;
						}
					}
					else
					{
						ViewBag.Message = "what happen to the ID?";
						ViewBag.emrHeaderID = 0;
						TempData["emrHeaderID"] = 0;
						return View("Error");
					}
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";

					controllerName = "Home";
					viewName = "UserLogin";
				}
			}
			catch (Exception ex)
			{
				//throw ex;
				ViewBag.Message = ex.Message;
				return View("Error");
			}


			return RedirectToAction(viewName, controllerName);
		}

		[HttpPost]
		public ActionResult archiveApprovals(FormCollection frm)
		{
			ViewBag.Title = "archiveApprovals [GET] ActionResult";
			List<TrustedI10model.workflow.m_workqeueOBJ> wqlst = new List<TrustedI10model.workflow.m_workqeueOBJ>();

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;


					// getting list for dropdown
					ViewBag.providerItems = WorkFlowPototype.App_Code.dataConnect.getProviderSelectListItem(user_obj.databaseName, true);
					ViewBag.facilityItems = WorkFlowPototype.App_Code.General.getFacilitySelectListItem(user_obj.facilities, "", "", true);

					Models.inParam inParam = new Models.inParam();

					inParam.facilityIDs = "all";
					inParam.providerIDs = "all";

					if (!string.IsNullOrEmpty(frm["daterange"]))
						inParam.DateRange = frm["daterange"];
					if (!string.IsNullOrEmpty(frm["facilityItems"]))
						inParam.facilityIDs = frm["facilityItems"];
					if (!string.IsNullOrEmpty(frm["providerItems"]))
						inParam.providerIDs = frm["providerItems"];

					inParam.userID = user_obj.id;
					inParam.clientID = user_obj.clientID;
					inParam.db = user_obj.databaseName;
					//// this is where we need to extract from dropdowns...  For now, I'm going to show all


					//---- must have these values ----//
					inParam.statusCodes = "all";    // when provider approved.  it goes into archive.
					inParam.teamMemberIDs = "all";  // team members does not apply to this report, just default to 'all' because we share the same store procedure with other report
					inParam.reportNumber = 3;

					wqlst = WorkFlowPototype.App_Code.dataConnect.getWQreport1(inParam);

					return View(wqlst);
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				return View("Error", ex);
			}
		}

		[HttpGet]
		public ActionResult DailyActivity(int facilityItems = 0, string statusItems = "", int teamItems = 0)
		{
			ViewBag.Title = "DailyActivity [GET] ActionResult";
			List<TrustedI10model.workflow.m_workqeueOBJ> wqlst = new List<TrustedI10model.workflow.m_workqeueOBJ>();
			ViewBag.Message = "";

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					Models.inParam inParam = new Models.inParam();
					inParam.userID = user_obj.id;
					inParam.clientID = user_obj.clientID;
					inParam.db = user_obj.databaseName;
					//// this is where we need to extract from dropdowns...  For now, I'm going to show all
					if (facilityItems > 0)
						inParam.facilityIDs = facilityItems.ToString();
					else
						inParam.facilityIDs = "all";
					inParam.providerIDs = "all";
					if (!string.IsNullOrEmpty(statusItems))
						inParam.statusCodes = statusItems;
					else
						inParam.statusCodes = "all";
					if (teamItems > 0)
						inParam.teamMemberIDs = teamItems.ToString();
					else
						inParam.teamMemberIDs = "all";
					// must have 
					inParam.reportNumber = 2;

					// getting list for dropdown

					ViewBag.teamItems = WorkFlowPototype.App_Code.General.getTeamSelectListItem(user_obj.teamMembers, "", "", true);
					ViewBag.Assing2TeamItems = WorkFlowPototype.App_Code.General.getTeamSelectListItem(user_obj.teamMembers, "", "", false);

					ViewBag.facilityItems = WorkFlowPototype.App_Code.General.getFacilitySelectListItem(user_obj.facilities, "", "", true);
					ViewBag.statusItems = WorkFlowPototype.App_Code.dataConnect.getStatusSelectListItem(user_obj.databaseName, true, inParam.reportNumber);

					wqlst = WorkFlowPototype.App_Code.dataConnect.getWQreport1(inParam);

					return View(wqlst);

					//return View();
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				return View("Error", ex);
			}
		}

		[HttpGet]
		public ActionResult isssueMR()
		{

			ViewBag.Title = "IssueMR [GET] ActionResult";
			List<TrustedI10model.workflow.m_workqeueOBJ> wqlst = new List<TrustedI10model.workflow.m_workqeueOBJ>();

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;


					// getting list for dropdown
					ViewBag.providerItems = WorkFlowPototype.App_Code.dataConnect.getProviderSelectListItem(user_obj.databaseName, true);
					ViewBag.facilityItems = WorkFlowPototype.App_Code.General.getFacilitySelectListItem(user_obj.facilities, "", "", true);

					// getting list for dropdown
					if (user_obj.accessLevel == 10)
					{
						ViewBag.teamItems = WorkFlowPototype.App_Code.General.getTeamSelectListItem(user_obj.teamMembers, user_obj.firstname + " " + user_obj.lastname, user_obj.id.ToString(), false);
					}
					else
					{
						ViewBag.teamItems = WorkFlowPototype.App_Code.General.getTeamSelectListItem(user_obj.teamMembers, "", "", false);
					}

					Models.inParam inParam = new Models.inParam();
					inParam.userID = user_obj.id;
					inParam.clientID = user_obj.clientID;
					inParam.db = user_obj.databaseName;
					//// this is where we need to extract from dropdowns...  For now, I'm going to show all
					inParam.facilityIDs = "all";
					inParam.providerIDs = "all";

					//---- must have these values ----//
					inParam.statusCodes = "all";    // will take care of in in sp
					inParam.teamMemberIDs = "all";  // team members does not apply to this report, just default to 'all' because we share the same store procedure with other report
					inParam.reportNumber = 1;

					wqlst = WorkFlowPototype.App_Code.dataConnect.getWQreport1(inParam);

					return View(wqlst);
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				return View("Error", ex);
			}

		}


		[HttpPost]
		public ActionResult DailyActivity(FormCollection frm)
		{
			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					return View();
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				//throw ex;
				ViewBag.Title = "workQueue ActionResult";
				return View("Error", ex);
			}
		}


		[HttpGet]
		public ActionResult Reports()
		{

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					return View();
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				//throw ex;
				ViewBag.Title = "workQueue ActionResult";
				return View("Error", ex);
			}
		}

		[HttpGet]
		public ActionResult Usersetup()
		{

			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				if (user_obj != null)
				{
					ViewBag.clientName = user_obj.clientName;
					ViewBag.userName = user_obj.firstname;
					ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
					ViewBag.userID = user_obj.id;
					ViewBag.accessLevel = user_obj.accessLevel;

					return View();
				}
				else
				{
					ViewBag.Message = "Session Time Out, Please re-login.";
					return RedirectToAction("UserLogin", "Home");
				}
			}
			catch (Exception ex)
			{
				//throw ex;
				ViewBag.Title = "workQueue ActionResult";
				return View("Error", ex);
			}
		}

		#region New Added Methods
		[HttpPost] 
		public JsonResult SaveWholeEMR(FormCollection formdata, string emrHeaderID)
		{
			//Note: Save Data Process- You will get Object all form data
			string Message = string.Empty;//Success or Failed Message of Save Operation
			bool IsError = false;
			TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
			TrustedI10model.workflow.m_wholeEMR objWholeEMR = (TrustedI10model.workflow.m_wholeEMR)TempData["ModelData"];
			TrustedI10DataContext.App_Code.Biz.workQueue.updateWholeMR(objWholeEMR, user_obj.databaseName);
			return Json(new { message = Message, iserror = IsError });
		}
		[HttpPost] 
		public JsonResult LineItemGridUpdateOnly(string[] lineItemData, string[] lineItemKeys, string tablename,int emrHdID, bool IsUpdate = false)
		{
			string Data = string.Empty;//Getting Data from ReBuild LineItem Grid
			string Message = string.Empty;//Success or Failed Message of Add/Update Operation
			bool IsError = false;
			m_codeSelected objCodeSelected = new m_codeSelected();
			objCodeSelected.code = lineItemData[Array.IndexOf(lineItemKeys, "code")];
			objCodeSelected.modifiers = lineItemData[Array.IndexOf(lineItemKeys, "modifier")];
			objCodeSelected.diagnosis = lineItemData[Array.IndexOf(lineItemKeys, "diagnosis")];
			objCodeSelected.unit = Convert.ToInt32(lineItemData[Array.IndexOf(lineItemKeys, "unit")]);
			objCodeSelected.type = lineItemData[Array.IndexOf(lineItemKeys, "type")];

			//Note: Logic of Add and Update from Pop up will goes here
			///
			///
			///
			///

			TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
			TrustedI10model.workflow.m_wholeEMR objWholeEmR = new TrustedI10model.workflow.m_wholeEMR();
			objWholeEmR.lstLineItems = GetGridDataFromDatabaseDxLi(emrHdID, user_obj.databaseName, "li");
			Data = RenderPartialViewToString("Shared/_LineItemGrid", objWholeEmR);
			return Json(new { message = Message, data = Data, iserror = IsError });
		}
		[HttpPost] 
		public JsonResult DiagnosisLineItemGridDeleteOnly(int[] emrHdID, int[] primaryIds, string codeType)
		{
			string Message = string.Empty;
			bool IsError = false;
			string Data = string.Empty;
			try
			{
				if (codeType == "D")
				{
					codeType = "dx";
				}
				else
					codeType = "li";
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				List<m_codeSelected> objListCodeSelected = new List<m_codeSelected>();
				if (emrHdID.Length > 0)
					objListCodeSelected = GetGridDataFromDatabaseDxLi(emrHdID[0], user_obj.databaseName, codeType);
				objListCodeSelected = objListCodeSelected.FindAll(x => Array.IndexOf(primaryIds, x.id) > -1);

				foreach (var deleteitem in objListCodeSelected)
				{
					deleteitem.id = -1;
					if (codeType == "dx")
					{
						TrustedI10DataContext.App_Code.Biz.workQueue.updateDX(deleteitem, user_obj.databaseName);
					}
					else
					{
						TrustedI10DataContext.App_Code.Biz.workQueue.updateLI(deleteitem, user_obj.databaseName);
					}
				}
				Message = "Data deleted successfully";
				//Reload Grid After delete Data in Diagnosis or LineItem
				TrustedI10model.workflow.m_wholeEMR objWholeEmR = new TrustedI10model.workflow.m_wholeEMR();
				if (emrHdID.Length > 0)
				{
					if (codeType == "dx")
					{
						objWholeEmR.lstDiag = GetGridDataFromDatabaseDxLi(emrHdID[0], user_obj.databaseName, codeType);
						Data = RenderPartialViewToString("Shared/_DiagnosisGrid", objWholeEmR);
					}
					else
					{
						objWholeEmR.lstLineItems = GetGridDataFromDatabaseDxLi(emrHdID[0], user_obj.databaseName, codeType);
						Data = RenderPartialViewToString("Shared/_LineItemGrid", objWholeEmR);
					}
				}
			}
			catch
			{
				IsError = true;
				Message = "Failed to delete data";
			}
			return Json(new { data = Data, message = Message, iserror = IsError });
		}
		[HttpPost] 
		public JsonResult ManageToDiagnosisLineItemGrid(List<m_codefound> liCopyForI10OrI9, string tablename, bool IsUpdate = false)
		{
			string Message = string.Empty;
			Boolean IsError = false;
			string Data = string.Empty;
			try
			{
				TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
				string code_type = ""; int emrHDid = 0;
				foreach (var diagnosis in liCopyForI10OrI9)
				{
					m_codeSelected objCodeSelected = new m_codeSelected();
					objCodeSelected.code = diagnosis.code;
					objCodeSelected.type = diagnosis.type;
					objCodeSelected.code_descr = diagnosis.descr;
					objCodeSelected.code_long_descr = diagnosis.long_descr;
					objCodeSelected.emrHdID = diagnosis.emrHdID;
					code_type = diagnosis.type;
					emrHDid = diagnosis.emrHdID;

					if (tablename == "D")//D for Diagnosis, L For Line Item
					{
						TrustedI10DataContext.App_Code.Biz.workQueue.updateDX(objCodeSelected, user_obj.databaseName);
					}
					else
					{
						if (IsUpdate)
							objCodeSelected.id = -2;
						TrustedI10DataContext.App_Code.Biz.workQueue.updateLI(objCodeSelected, user_obj.databaseName);
					}
				}
				//Reload Grid After Copy Data in Diagnosis or LineItem
				TrustedI10model.workflow.m_wholeEMR objWholeEmR = new TrustedI10model.workflow.m_wholeEMR();

				if (tablename == "D")
				{
					objWholeEmR.lstDiag = GetGridDataFromDatabaseDxLi(emrHDid, user_obj.databaseName, "dx");
					Data = RenderPartialViewToString("Shared/_DiagnosisGrid", objWholeEmR);
					Message = "Data copied to Diagnosis successfully";
				}
				else
				{
					objWholeEmR.lstLineItems = GetGridDataFromDatabaseDxLi(emrHDid, user_obj.databaseName, "li");
					Data = RenderPartialViewToString("Shared/_LineItemGrid", objWholeEmR);

					Message = "Data copied to Line Item successfully";
				}

			}
			catch
			{
				Message = "Failed to copy data to diagnosis grid.";
				IsError = true;
			}
			return Json(new { data = Data, message = Message, iserror = IsError });
		}
		[HttpPost] 
		public JsonResult UploadFiles(int facilityid, string facilityname)
		{
			string Message = "";
			bool IsError = false;
			TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
			if (Request.Files.Count > 0)
			{
				BinaryReader b = new BinaryReader(Request.Files[0].InputStream);
				MemoryStream target = new MemoryStream();
				Request.Files[0].InputStream.CopyTo(target);
				byte[] binData = target.ToArray();
				string result = System.Text.Encoding.UTF8.GetString(binData);

				m_uploadFile objUploadFile = new m_uploadFile();

				objUploadFile.facilityID = facilityid;
				objUploadFile.whoUploadID = user_obj.id;
				objUploadFile.filename = Request.Files[0].FileName;
				objUploadFile.filedate = DateTime.Now.ToString();
				objUploadFile.uploaded = DateTime.Now.ToString();
				//objUploadFile.emrHdID=
				objUploadFile.texts = result;
				objUploadFile.whoUploadName = user_obj.firstname;
				objUploadFile.facilityName = facilityname;
				objUploadFile.db4UpdateDB = objGeneral.GetCurrentClientDB();
				dataConnect.insertUploadFile(objUploadFile, objUploadFile.db4UpdateDB);
				Message = "File Uploaded Successfully.";
			}
			return Json(new { Message, IsError });
		}
		
		public List<m_codeSelected> GetGridDataFromDatabaseDxLi(int emrHdId, string db, string code_type)
		{
			return TrustedI10DataContext.App_Code.Data.workQueue.getEMR_CodeSelected(emrHdId, db, code_type);
		}

		protected string RenderPartialViewToString(string viewName, object model)
		{
			string toReturn;
			if (string.IsNullOrEmpty(viewName))
				viewName = ControllerContext.RouteData.GetRequiredString("action");

			ViewData.Model = model;
			using (StringWriter sw = new StringWriter())
			{
				ViewEngineResult viewResult = ViewEngines.Engines.FindPartialView(ControllerContext, viewName);
				ViewContext viewContext = new ViewContext(ControllerContext, viewResult.View, ViewData, TempData, sw);
				viewResult.View.Render(viewContext, sw);
				toReturn = sw.GetStringBuilder().ToString();
				return toReturn;
			}
		}
		#endregion
	}
}
