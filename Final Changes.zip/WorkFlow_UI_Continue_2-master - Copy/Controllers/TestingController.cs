﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WorkFlowPototype.Controllers
{
    public class TestingController : Controller
    {
        // GET: Testing

        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string submitButton)
        {
            string db = "groupabc";
            int emrHdId = 1;
            int userID = 1;
            int facID = 1;
            int lcdID = 36408;

            if (submitButton != null)
            {
                switch (submitButton)
                {
                    case "Save upload the file":

                        // pretend we are uploading
                        TrustedI10model.workflow.m_uploadFile obj = new TrustedI10model.workflow.m_uploadFile();
                        obj.facilityID = facID;
                        obj.whoUploadID = 2;
                        obj.filedate = "7/15/2017";
                        obj.filename = "testUploadFromFrontEnd.txt";
                        obj.texts = "Doctor long nots........";
                        WorkFlowPototype.App_Code.dataConnect.insertUploadFile(obj, db);

                        break;

                    case "Save":
                        // save


                        TrustedI10model.workflow.m_wholeEMR mrOBJ = new TrustedI10model.workflow.m_wholeEMR();

                        TrustedI10model.workflow.m_emrHeader header = new TrustedI10model.workflow.m_emrHeader();
                        List<TrustedI10model.workflow.m_codeSelected> dx = new List<TrustedI10model.workflow.m_codeSelected>();
                        List<TrustedI10model.workflow.m_codeSelected> li = new List<TrustedI10model.workflow.m_codeSelected>();
                        List<TrustedI10model.workflow.m_emrNoteOBJ> notes = new List<TrustedI10model.workflow.m_emrNoteOBJ>();

                        TrustedI10model.workflow.m_codeSelected dxOBJ = new TrustedI10model.workflow.m_codeSelected();
                        TrustedI10model.workflow.m_codeSelected liOBJ = new TrustedI10model.workflow.m_codeSelected();
                        TrustedI10model.workflow.m_emrNoteOBJ noteObj = new TrustedI10model.workflow.m_emrNoteOBJ();

                        noteObj.userID = userID;
                        noteObj.note = "Testing update.....";
                        notes.Add(noteObj);
                        mrOBJ.lstNotes = notes;

                        // extract from db, will pretend we make changes and call th update
                        dx = TrustedI10DataContext.App_Code.Data.workQueue.getEMR_CodeSelected(emrHdId, db, "dx");
                        li = TrustedI10DataContext.App_Code.Data.workQueue.getEMR_CodeSelected(emrHdId, db, "li");
                        header = TrustedI10DataContext.App_Code.Data.workQueue.getEMR_Header(emrHdId, db);

                        // making changes
                        // may be we can just pass in just the  one being update...
                        // id=0, add
                        // id=-1, remove
                        // id=-2, update
                        break;

                    case "Check the Codes":
                        // check the  code
                        TrustedI10model.workflow.m_CheckCodeResult checkCodeObj = WorkFlowPototype.App_Code.dataConnect.getEMResult(emrHdId, facID, db);
                        break;

                    case "Search for Codes":
                        return RedirectToAction("CodeSearch", "Regulatory");
                       
                    case "view LCD/NCD":
                        if (lcdID > 0)
                        {
                           // return RedirectToAction("Index", "Regulatory");
                           return RedirectToAction("viewLCD", "Regulatory", new { lcdID = lcdID });
                        }
                        break;

                    case "Reset Test Data":
                        WorkFlowPototype.App_Code.dataConnect.resetTestData(db);
                        break;

                    case "NLP":

                        break;
                }
            }
            return View();
        }
    }
}