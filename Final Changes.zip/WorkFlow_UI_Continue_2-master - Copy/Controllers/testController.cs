﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using WorkFlowPototype.Models;
using TrustedI10DataContext.App_Code;

namespace WorkFlowPototype.Controllers
{
    public class testController : Controller
    {
        // GET: test
        public ActionResult Index()
        {


            return View();
        }

        public ActionResult FruitsWeEat()
        {
            List<Fruits> fr = new List<Fruits>();
            fr.Add(new WorkFlowPototype.Models.Fruits() { FruitID = 1, FruitName = "Apple" });
            fr.Add(new WorkFlowPototype.Models.Fruits() { FruitID = 2, FruitName = "Banana" });
            fr.Add(new WorkFlowPototype.Models.Fruits() { FruitID = 3, FruitName = "Cherry" });
            fr.Add(new WorkFlowPototype.Models.Fruits() { FruitID = 4, FruitName = "Dragon Fruit" });
            fr.Add(new WorkFlowPototype.Models.Fruits() { FruitID = 5, FruitName = "Mango" });
            FruitLst frlst = new FruitLst();
            frlst.fruits = fr;

            return View(frlst);
        }

        [HttpPost]
        public ActionResult FruitsWeEat(FruitLst frl)
        {
            StringBuilder sb = new StringBuilder();
            foreach(var item in frl.fruits)
            {
                if (item.IsCheck)
                {
                    sb.Append(item.FruitName + ", ");
                }

            }
            ViewBag.selectedFruits = "Selected Fruits " + sb.ToString();
            return View(frl);
        }

        public ActionResult testing()
        {
            List<TrustedI10model.workflow.m_unassignWQobj> wqLst = new List<TrustedI10model.workflow.m_unassignWQobj>();
            wqLst = TrustedI10DataContext.App_Code.Biz.workQueue.getUnassignWQ(1, "groupabc");
            unassignObj viewObj;
            unassignLst viewLst = new unassignLst();

            foreach (TrustedI10model.workflow.m_unassignWQobj obj in wqLst)
            {
                viewObj = new unassignObj();
                viewObj.emrHdID = obj.emrHdID;
                viewObj.filename = obj.fileName;
                viewObj.facilityName = obj.facilityName;
                viewObj.uploaded_date = obj.uploaded;
                viewObj.whoUploaded = obj.whoUploaded;
                viewLst.wqLst.Add(viewObj);
            }
            return View(viewLst);
        }

        [HttpPost]
        public ActionResult testing(unassignLst lst)
        {
            StringBuilder sb = new StringBuilder();
            foreach (var item in lst.wqLst)
            {
                if (item.IsCheck)
                {
                    sb.Append(item.filename + ", ");
                }

            }
            ViewBag.selected = "Selected Fruits " + sb.ToString();
            return View(lst);
        }
    }
}