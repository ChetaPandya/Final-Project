﻿using System.Collections.Generic;
using System.Web.Mvc;

namespace WorkFlowPototype.Controllers
{
    public class RegulatoryController : Controller
    {
        // GET: Regulatory
        public ActionResult Index()
        {

            return View();
        }

        public ActionResult viewLCD(int? lcdID)
        {

            int lcd_id = lcdID ?? default(int);

            RegulatoryDB.App_Code.Model.LCDview obj = WorkFlowPototype.App_Code.dataConnect.getLCDset(lcd_id);
            return View(obj);
        }

        public ActionResult CodeSearch(string whichSearch, string search1, string search2, string search3)
        {

            /// cheta,
            /// whichSearch will be base on which one {dx = Diagnosis or li = line item}
            

            if (whichSearch== null || whichSearch == "")
            {
                // for testing
                whichSearch = "dx";
            }

            List<RegulatoryDB.App_Code.Model.Code> lst = new List<RegulatoryDB.App_Code.Model.Code>();

            if (search1 !=null || search2!=null || search3 != null) {
                lst = WorkFlowPototype.App_Code.dataConnect.CodeSearch(whichSearch, search1, search2, search3);
            }
            return View(lst);
        }

    }
}