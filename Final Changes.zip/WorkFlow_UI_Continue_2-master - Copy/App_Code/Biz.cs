﻿using System.Collections.Generic;
using System.Configuration;
using System.Web.Mvc;
using System.Web.Script.Serialization;

namespace WorkFlowPototype.App_Code
{
	public class Biz
	{


	}

	public class menuLayout
	{
		public static string getLayout(int accessLevel)
		{

			string viewFile = "";
			string coderLayout = "~/Views/Shared/_CodereLayout.cshtml";
			string managerLayout = "~/Views/Shared/_ManagerLayout.cshtml";
			string adminLayout = "~/Views/Shared/_ManagerLayout.cshtml";
			string providerLayout = "~/Views/Shared/_ProviderLayout.cshtml";

			if (accessLevel == 100)
			{
				viewFile = adminLayout;
			}

			else if (accessLevel == 10)
			{
				viewFile = coderLayout;
			}

			else if (accessLevel == 5)
			{
				viewFile = providerLayout;
			}
			else // has to be manager or admin
			{
				viewFile = managerLayout;
			}
			return viewFile;
		}
	}

	public class dataConnect
	{
		private static string appMode = ConfigurationManager.AppSettings["appMode"].ToString();
		private static string WhereIsTheData = ConfigurationManager.AppSettings["WhereIsTheData"].ToString();
		private static string dbConnectMethod = ConfigurationManager.AppSettings["dbConnectMethod"].ToString();

		public static string getConnection(string app_mode_key, string whichOne)
		{
			string rtn = "";

			if (app_mode_key == "local")
			{
				if (whichOne == "main")
				{
					rtn = ConfigurationManager.ConnectionStrings["mySQL_MainDB"].ConnectionString;
				}
				else if (whichOne == "client")
				{
					rtn = ConfigurationManager.ConnectionStrings["mySQL_ClientDB"].ConnectionString;
				}
			}

			else
			{
				if (whichOne == "main")
				{
					rtn = ConfigurationManager.ConnectionStrings["mySQL_MainDB_aws"].ConnectionString;
				}
				else if (whichOne == "client")
				{
					rtn = ConfigurationManager.ConnectionStrings["mySQL_ClientDB_aws"].ConnectionString;
				}
			}

			return rtn;
		}

		// ------------------- for lookup list -----------//

		public static List<TrustedI10model.lookup.m_id_descr> callSPwithParamReturnIdDescr(Models.inParam inparam)
		{
			List<TrustedI10model.lookup.m_id_descr> lst = new List<TrustedI10model.lookup.m_id_descr>();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//
			string jsonString;
			string result;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(inparam);
					result = client.callSPwithParamReturnIdDescr(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.lookup.m_id_descr>>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(inparam);
					result = client.callSPwithParamReturnIdDescr(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.lookup.m_id_descr>>(result);
				}
			}
			// call class straigh to get data
			else
			{
				lst = TrustedI10DataContext.App_Code.Data.GeneralSQLcall.callSPwithParamReturnIdDescr(inparam.other, inparam.db);
			}

			return lst;
		}

		public static List<TrustedI10model.lookup.m_id_descr> getStatus4Report(Models.inParam inparam)
		{
			List<TrustedI10model.lookup.m_id_descr> lst = new List<TrustedI10model.lookup.m_id_descr>();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//
			string jsonString;
			string result;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(inparam);
					result = client.getStatus4Report(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.lookup.m_id_descr>>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(inparam);
					result = client.getStatus4Report(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.lookup.m_id_descr>>(result);
				}
			}
			// call class straigh to get data
			else
			{
				lst = TrustedI10DataContext.App_Code.Data.GeneralSQLcall.getStatus4Report(inparam.reportNumber, inparam.db);
			}

			return lst;
		}
		public static List<RegulatoryDB.App_Code.Model.Code> CodeSearch(string searchType, string search1, string search2, string search3)
		{
			List<RegulatoryDB.App_Code.Model.Code> lst = new List<RegulatoryDB.App_Code.Model.Code>();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//
			string jsonString;
			string result;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{

				}
				else if (WhereIsTheData == "local")
				{

				}
			}
			// call class straigh to get data
			else
			{
				lst = RegulatoryDB.App_Code.Data.CodeLookupData_mySQL.CodeSearch(searchType, search1, search2, search3);
			}

			return lst;
		}
		// ------------------- client info ----------------//
		public static TrustedI10model.client.m_userOBJ getUserLogin(TrustedI10model.client.m_loginRequirement user)
		{
			TrustedI10model.client.m_userOBJ objUser = new TrustedI10model.client.m_userOBJ();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsClientInfo.clientInfoSoapClient client = new awsClientInfo.clientInfoSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(user);
					result = client.UserLogin(jsonString);
					objUser = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.client.m_userOBJ>(result);
				}
				else if (WhereIsTheData == "local")
				{
					clientInfo.clientInfoSoapClient client = new clientInfo.clientInfoSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(user);
					result = client.UserLogin(jsonString);
					objUser = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.client.m_userOBJ>(result);
				}
			}
			// call class straigh to get data
			else
			{
				objUser = TrustedI10DataContext.App_Code.Biz.userLogin.getUserLogin(user.userLogin, user.password);
			}

			return objUser;
		}
		
		
		//---------------------regulatory ---------------------//
		public static RegulatoryDB.App_Code.Model.LCDview getLCDset(int lcdID)
		{
			RegulatoryDB.App_Code.Model.LCDview obj = new RegulatoryDB.App_Code.Model.LCDview();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
				}
				else if (WhereIsTheData == "local")
				{
				}
			}
			// call class straigh to get data
			else
			{
				obj = RegulatoryDB.App_Code.Biz.LCDBiz_mySQL.getLCDset(lcdID);
			}
			return obj;
		}
		//--------------------- work queue ---------------------//

		public static List<TrustedI10model.workflow.m_workqeueOBJ> getWorkQueue(int userID, string db)
		{

			List<TrustedI10model.workflow.m_workqeueOBJ> lst = new List<TrustedI10model.workflow.m_workqeueOBJ>();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;


			Models.inParam xObj = new Models.inParam();
			xObj.userID = userID;
			xObj.emrID = 0;
			xObj.db = db;


			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getWorkQueue(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.workflow.m_workqeueOBJ>>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getWorkQueue(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.workflow.m_workqeueOBJ>>(result);
				}
			}
			// call class straigh to get data
			else
			{
				lst = TrustedI10DataContext.App_Code.Biz.workQueue.getWorkQueue(userID, db);
			}

			return lst;
		}

		public static List<TrustedI10model.workflow.m_unassignWQobj> getNonAssign(int userID, string db)
		{

			List<TrustedI10model.workflow.m_unassignWQobj> lst = new List<TrustedI10model.workflow.m_unassignWQobj>();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;


			Models.inParam xObj = new Models.inParam();
			xObj.userID = userID;
			xObj.emrID = 0;
			xObj.db = db;


			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getNonAssign(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.workflow.m_unassignWQobj>>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getNonAssign(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.workflow.m_unassignWQobj>>(result);
				}
			}
			// call class straigh to get data
			else
			{
				lst = TrustedI10DataContext.App_Code.Biz.workQueue.getUnassignWQ(userID, db);
			}

			return lst;
		}

		public static TrustedI10model.workflow.m_emrHeader getEMR_Header(int emrID, string db)
		{

			TrustedI10model.workflow.m_emrHeader obj = new TrustedI10model.workflow.m_emrHeader();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;


			Models.inParam xObj = new Models.inParam();
			xObj.userID = 0;
			xObj.emrID = emrID;
			xObj.db = db;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getEMR_Header(jsonString);
					obj = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.workflow.m_emrHeader>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getEMR_Header(jsonString);
					obj = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.workflow.m_emrHeader>(result);
				}
			}
			// call class straigh to get data
			else
			{
				obj = TrustedI10DataContext.App_Code.Biz.workQueue.getEMR_Header(emrID, db);
			}

			return obj;
		}

		public static TrustedI10model.workflow.m_wholeEMR getWholeEMR(int emrID, string db)
		{

			TrustedI10model.workflow.m_wholeEMR obj = new TrustedI10model.workflow.m_wholeEMR();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;


			Models.inParam xObj = new Models.inParam();
			xObj.userID = 0;
			xObj.emrID = emrID;
			xObj.db = db;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getWholeEMR(jsonString);
					obj = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.workflow.m_wholeEMR>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(xObj);
					result = client.getWholeEMR(jsonString);
					obj = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.workflow.m_wholeEMR>(result);
				}
			}
			// call class straigh to get data
			else
			{
				obj = TrustedI10DataContext.App_Code.Biz.workQueue.getWholeMR(emrID, db);
			}

			return obj;
		}

		public static List<SelectListItem> getProviderSelectListItem(string db, bool all)
		{
			List<SelectListItem> items = new List<SelectListItem>();
			List<TrustedI10model.lookup.m_id_descr> visitLst = new List<TrustedI10model.lookup.m_id_descr>();
			Models.inParam inparam = new Models.inParam();

			inparam = new Models.inParam();
			inparam.db = db;
			inparam.other = "getProviders2_sp";
			visitLst = callSPwithParamReturnIdDescr(inparam);
			items = new List<SelectListItem>();

			if (all)
			{
				items.Add(new SelectListItem { Text = "** All Providers **", Value = "all" });
			}
			else
			{
				items.Add(new SelectListItem { Text = "** Please select Provider **", Value = "0" });
			}

			foreach (TrustedI10model.lookup.m_id_descr o in visitLst)
			{
				if (visitLst.Count == 1)
					items.Add(new SelectListItem { Text = o.descr, Value = o.id.ToString(), Selected = true });
				else
					items.Add(new SelectListItem { Text = o.descr, Value = o.id.ToString() });
			}

			return items;

		}

		public static List<SelectListItem> getVisitSelectListItem(string db, bool all)
		{
			List<SelectListItem> items = new List<SelectListItem>();
			List<TrustedI10model.lookup.m_id_descr> visitLst = new List<TrustedI10model.lookup.m_id_descr>();
			Models.inParam inparam = new Models.inParam();

			inparam = new Models.inParam();
			inparam.db = "";
			inparam.other = "getVisits_sp";
			visitLst = callSPwithParamReturnIdDescr(inparam);
			items = new List<SelectListItem>();

			if (all)
			{
				items.Add(new SelectListItem { Text = "** All Type of Visits **", Value = "all" });
			}
			else
			{
				items.Add(new SelectListItem { Text = "** Please select Type of Visit **", Value = "0" });
			}

			foreach (TrustedI10model.lookup.m_id_descr o in visitLst)
			{
				items.Add(new SelectListItem { Text = o.descr, Value = o.id.ToString() });
			}


			return items;

		}

		public static List<SelectListItem> getStatusSelectListItem(string db, bool all)
		{
			List<SelectListItem> items = new List<SelectListItem>();
			List<TrustedI10model.lookup.m_id_descr> visitLst = new List<TrustedI10model.lookup.m_id_descr>();
			Models.inParam inparam = new Models.inParam();

			inparam = new Models.inParam();
			inparam.db = "";
			inparam.other = "getStatusCodes_sp";
			visitLst = callSPwithParamReturnIdDescr(inparam);
			items = new List<SelectListItem>();
			if (all)
			{
				items.Add(new SelectListItem { Text = "** All Statuses **", Value = "all" });
			}
			else
			{
				items.Add(new SelectListItem { Text = "** Please select Status **", Value = "" });
			}
			foreach (TrustedI10model.lookup.m_id_descr o in visitLst)
			{

				items.Add(new SelectListItem { Text = o.code + "-" + o.descr, Value = o.code.ToString() });
			}


			return items;

		}

		public static List<SelectListItem> getStatusSelectListItem(string db, bool all, int whichReport)
		{
			List<SelectListItem> items = new List<SelectListItem>();
			List<TrustedI10model.lookup.m_id_descr> lst = new List<TrustedI10model.lookup.m_id_descr>();
			Models.inParam inparam = new Models.inParam();

			inparam = new Models.inParam();
			inparam.db = "";
			inparam.reportNumber = whichReport;
			lst = getStatus4Report(inparam);

			items = new List<SelectListItem>();
			if (all)
			{
				items.Add(new SelectListItem { Text = "** All Statuses **", Value = "all" });
			}
			else
			{
				items.Add(new SelectListItem { Text = "** Please select Status **", Value = "" });
			}
			foreach (TrustedI10model.lookup.m_id_descr o in lst)
			{

				items.Add(new SelectListItem { Text = o.code + "-" + o.descr, Value = o.code.ToString() });
			}


			return items;

		}

		public static List<TrustedI10model.workflow.m_workqeueOBJ> getWQreport1(Models.inParam obj)
		{

			List<TrustedI10model.workflow.m_workqeueOBJ> lst = new List<TrustedI10model.workflow.m_workqeueOBJ>();

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					result = client.getWQreport1(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.workflow.m_workqeueOBJ>>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					result = client.getWQreport1(jsonString);
					lst = Newtonsoft.Json.JsonConvert.DeserializeObject<List<TrustedI10model.workflow.m_workqeueOBJ>>(result);
				}
			}
			// call class straigh to get data
			else
			{
				lst = TrustedI10DataContext.App_Code.Biz.workQueue.getWQreport1(obj.userID, obj.clientID, obj.db, obj.reportNumber, obj.facilityIDs, obj.statusCodes, obj.teamMemberIDs, obj.providerIDs);
			}

			return lst;
		}


		// -------------------- save data ----------------//

		public static void makingAssignment(TrustedI10model.workflow.m_assignment obj, string db)
		{

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					client.makingAssignment(jsonString);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					client.makingAssignment(jsonString);
				}
			}
			// call class straigh to get data
			else
			{
				TrustedI10DataContext.App_Code.Data.workQueue.makingAssignment(obj, db);
			}
		}

		public static void updateStatus(TrustedI10model.workflow.m_assignment obj, string db)
		{

			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					client.updateStatus(jsonString);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					client.updateStatus(jsonString);
				}
			}
			// call class straigh to get data
			else
			{
				TrustedI10DataContext.App_Code.Data.workQueue.updateStatus(obj, db);
			}


		}

		public static void makingAssignment(List<TrustedI10model.workflow.m_assignment> lst, string db)
		{
			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(lst);
					client.makingAssignment(jsonString);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(lst);
					client.makingAssignment(jsonString);
				}
			}
			// call class straigh to get data
			else
			{
				TrustedI10DataContext.App_Code.Biz.workQueue.makingAssignment(lst, db);
			}
		}

		public static void insertUploadFile(TrustedI10model.workflow.m_uploadFile obj, string db)
		{
			obj.db4UpdateDB = db;
			int newID;
			// ---------------- switch from local and amazon call, api or straigh class call -------------//

			string jsonString;
			string result;

			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					result = client.insertUploadFile(jsonString);
					newID = Newtonsoft.Json.JsonConvert.DeserializeObject<int>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					result = client.insertUploadFile(jsonString);
					newID = Newtonsoft.Json.JsonConvert.DeserializeObject<int>(result);
				}
			}
			// call class straigh to get data
			else
			{
				TrustedI10DataContext.App_Code.Data.workQueue.insertOneEMRUploadFile(obj, db);
			}
		}

		public static void resetTestData(string db)
		{
			// only if the applicationg mode is in develpment or test
			if (appMode == "d" || appMode == "t")
			{
				// ---------------- switch from local and amazon call, api or straigh class call -------------//


				// call web api to get data
				if (dbConnectMethod == "api")
				{
					if (WhereIsTheData == "aws")
					{
						awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();

						client.resetTestData(db);
					}
					else if (WhereIsTheData == "local")
					{
						workflow.workflowSoapClient client = new workflow.workflowSoapClient();
						client.resetTestData(db);
					}
				}
				// call class straigh to get data
				else
				{
					TrustedI10DataContext.App_Code.Data.GeneralSQLcall.resetTestData(db);
				}
			}

		}

		public static TrustedI10model.workflow.m_CheckCodeResult getEMResult(int emrHdId, int facID, string db)
		{
			string jsonString = "";
			string result;

			TrustedI10model.workflow.m_CheckCodeResult rtn = new TrustedI10model.workflow.m_CheckCodeResult();
			WorkFlowPototype.Models.inParam obj = new Models.inParam();
			obj.db = db;
			obj.emrID = emrHdId;
			obj.facID = facID;

			// ---------------- switch from local and amazon call, api or straigh class call -------------//


			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					result = client.getEMResult(jsonString);
					rtn = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.workflow.m_CheckCodeResult>(result);
				}
				else if (WhereIsTheData == "local")
				{
					workflow.workflowSoapClient client = new workflow.workflowSoapClient();
					jsonString = new JavaScriptSerializer().Serialize(obj);
					result = client.getEMResult(jsonString);
					rtn = Newtonsoft.Json.JsonConvert.DeserializeObject<TrustedI10model.workflow.m_CheckCodeResult>(result);
				}
			}
			// call class straigh to get data
			else
			{
				rtn = TrustedI10DataContext.App_Code.Biz.workQueue.getEMResult(emrHdId, facID, db);
			}

			return rtn;
		}

		public static void updateWholeMR(TrustedI10model.workflow.m_wholeEMR obj, string db)
		{
			// ---------------- switch from local and amazon call, api or straigh class call -------------//


			// call web api to get data
			if (dbConnectMethod == "api")
			{
				if (WhereIsTheData == "aws")
				{
					//awsWorkFlow.workflowSoapClient client = new awsWorkFlow.workflowSoapClient();

					//client.makingAssignment(jsonString);
				}
				else if (WhereIsTheData == "local")
				{
					//workflow.workflowSoapClient client = new workflow.workflowSoapClient();

					//client.makingAssignment(jsonString);
				}
			}
			// call class straigh to get data
			else
			{
				TrustedI10DataContext.App_Code.Biz.workQueue.updateWholeMR(obj, db);
			}
		}
	}

	public class General
	{
		public static List<SelectListItem> getTeamSelectListItem(List<TrustedI10model.client.m_teamMember> inLst, string defaultDesc, string defaultValue, bool all)
		{
			List<SelectListItem> items = new List<SelectListItem>();

			if (all)
			{
				items.Add(new SelectListItem { Text = "** All Team Members **", Value = "all" });
			}
			else
			{
				items.Add(new SelectListItem { Text = "** Please select Team Member **", Value = "0" });
			}



			if (defaultValue != "" && defaultDesc != "")
			{
				items.Add(new SelectListItem { Text = defaultDesc, Value = defaultValue });
			}

			if (inLst != null)
			{
				foreach (TrustedI10model.client.m_teamMember o in inLst)
				{
					items.Add(new SelectListItem { Text = o.firstname + " " + o.lastname, Value = o.id.ToString() });
				}
			}

			return items;
		}

		public static List<SelectListItem> getFacilitySelectListItem(List<TrustedI10model.client.m_facility> inLst, string defaultDesc, string defaultValue, bool all)
		{
			List<SelectListItem> items = new List<SelectListItem>();
			if (all)
			{
				items.Add(new SelectListItem { Text = "** All Facilities **", Value = "all" });
			}
			else
			{
				items.Add(new SelectListItem { Text = "** Please select Facility **", Value = "0" });
			}


			if (defaultValue != "" && defaultDesc != "")
			{
				items.Add(new SelectListItem { Text = defaultDesc, Value = defaultValue });
			}

			if (inLst != null)
			{
				foreach (TrustedI10model.client.m_facility o in inLst)
				{
					items.Add(new SelectListItem { Text = o.name, Value = o.id.ToString() });
				}
			}

			return items;
		}

	}
}
