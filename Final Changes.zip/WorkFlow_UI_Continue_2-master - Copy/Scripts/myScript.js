﻿function showObj(item) {
    return $(item).show();
}
function hideObj(item) {
    return $(item).hide();
}

function disableObj(item) {
    return $(item).prop('disabled', true);
}
function enableObj(item) {
    return $(item).prop('disabled', false);
}

function diabledObjsWithIDs(ids) {
    $(ids).each(function (index, id) {
        disableObj(id);
    });
}
function endableObjsWithIDs(ids) {
    $(ids).each(function (index, id) {
        enableObj(id);
    });
}

function showObjsWithIDs(ids) {
    $(ids).each(function (index, id) {
        showObj(id);
    });
}
function hideObjsWithIDs(ids) {
    $(ids).each(function (index, id) {
        hideObj(id);
    });
}