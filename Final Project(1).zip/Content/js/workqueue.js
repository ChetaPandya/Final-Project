﻿$(document).ready(function () {
    $('#btnSaveUploadedfile').click(function () {
        if (window.FormData !== undefined) {

            var fileUpload = $("#fuUploadTextFile").get(0);
            var files = fileUpload.files;

            var fileData = new FormData();
            if ($("#facilityItems").val() == '0' || files.length == 0) {
                alert('Facility and File both are mandatory.');
                return;
            }
            for (var i = 0; i < files.length; i++) {
                fileData.append(files[i].name, files[i]);
            }
            // Adding one more key to FormData object  
            fileData.append('facilityid', $("#facilityItems").val());
            fileData.append('facilityname', $("#facilityItems option:selected").text());
            $.ajax({
                url: '/WorkQueue/UploadFiles',
                type: "POST",
                contentType: false, // Not to set any content header  
                processData: false, // Not to process data  
                data: fileData,
                success: function (result) {
                    alert(result.Message);
                    window.location.reload();
                },
                error: function (result) {
                    alert("Failed to Upload File");
                }
            });
        }
        else {
            alert("FormData is not supported.");
        }
    });

    //$('#ddlCodeTypeDiag').change(function () {
    //    GetValuesByCodeType('ddlCodeTypeDiag');
    //});
    //$('#ddlCodeType').change(function () {
    //    GetValuesByCodeType('ddlCodeType');
    //});

});
function GetValuesByCodeType(ddlId) {
    debugger;
   
    var grid = "";
    if (ddlId == 'ddlCodeType') {
        grid = "L";//L stands for line item
    }
    else {
        grid = "D";//D Stands for Diagnosis
    }
    var ddlCodetype = '';
    if (grid == "D")
        ddlCodetype = $("#txtCodeDiag");
    else
        ddlCodetype = $("#txtCode");
    ddlCodetype.empty().append('<option selected="selected" value="" shortdesc="" longdesc="">-- Select --</option>');

    if ($("#" + ddlId + " option:selected").index() == 0) {
        return;
    }

    if ($("#" + ddlId).val() != undefined && $("#" + ddlId).val() != '') {
        $.ajax({
            url: '/WorkQueue/CodeSearchByType',
            type: "POST",
            dataType: "json",
            data: { whichSearch: $("#" + ddlId).val() },
            success: function (result) {
                var codedata = JSON.parse(result.CodeData);
                for (var i = 0; i < codedata.length; i++) {
                    ddlCodetype.append("<option value='" + codedata[i]["code"] + "' shortdesc='" + codedata[i]["short_descr"] + "' longdesc='" + codedata[i]["long_descr"] + "'>" + codedata[i]["code"] + "</option>")
                    //var option = document.createElement('option');
                    //option.text = codedata[i]["code"];
                    //option.value = codedata[i]["short_descr"];
                    //option.attributes =
                    //select.add(option, 0);
                }

            },
            error: function (result) {
                alert('failed to get data');
            }
        });
    }
}
function CopyAnylizeCode(str) {
    alert(str);
}

