﻿using System.Collections.Generic;
using System.Web.Mvc;
using TrustedI10model.workflow;

namespace WorkFlowPototype.Models
{
    public class m_wholeEMR
    {
        public m_emrHeader headerRec { get; set; }
        public List<m_emrNoteOBJ> lstNotes { get; set; }
        public List<m_codefound> lstCPTCodeFound { get; set; }
        public List<m_codefound> lstHCPCCodeFound { get; set; }
        public List<m_codefound> lstEMCodeFound { get; set; }
        public List<m_codefound> lstI10CodeFound { get; set; }
        public List<m_codefound> lstI9CodeFound { get; set; }

        public List<m_codeSelected> lstDiag { get; set; }
        public List<m_codeSelected> lstLineItems { get; set; }

        public SelectList providerSelectLst { get; set; }


        public List<SelectListItem> visitItems { get; set; }

        public List<SelectListItem> providerItems { get; set; }

    }
}