﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WorkFlowPototype.Models
{
    public class inParam
    {
        public int userID { get; set; }
        public int clientID { get; set; }
        public int emrID { get; set; }
        public int facID { get; set; }
        public string db { get; set; }
        public string other { get; set; }
        public string facilityIDs { get; set; }
        public string statusCodes { get; set; }
        public string teamMemberIDs { get; set; }
        public string providerIDs { get; set; }
        public int reportNumber { get; set; }

		//New Added - __HP__
		public string DateRange { get; set; }
    }
}