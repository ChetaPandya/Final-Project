﻿using System;
using System.Web.Mvc;

namespace WorkFlowPototype.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index(int? resetTestData)
        {
            if (Session["user"] != null)
            {
                TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];

                ViewBag.clientName = user_obj.clientName;
                ViewBag.userName = "Welcome " + user_obj.firstname;
                ViewBag.layout = WorkFlowPototype.App_Code.menuLayout.getLayout(user_obj.accessLevel);
                ViewBag.userID = user_obj.id;
                if (resetTestData != null)
                {
                    // Someone click on the little lady. Reset the test data.  This is not for production
                    WorkFlowPototype.App_Code.dataConnect.resetTestData(user_obj.databaseName);
                }
            }
            else {                      
                ViewBag.clientName = "";
                ViewBag.userName ="";
                ViewBag.layout = "~/Views/Shared/_Layout.cshtml";
                ViewBag.userID = 0;
            }
           
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "";

            return View();
        }
        
        public ActionResult ClientSetup()
        {
            ViewBag.Message = "Client Setup";

            return View();
        }

        public ActionResult UserSetup()
        {
            ViewBag.Message = "User Setup";

            return View();
        }

        public ActionResult Reports()
        {
            ViewBag.Message = "Reports";

            return View();
        }

        public ActionResult UserLogin(TrustedI10model.client.m_loginRequirement user)
        {
  
            if (ModelState.IsValid)
            {
                TrustedI10model.client.m_userOBJ objUser = new TrustedI10model.client.m_userOBJ();
                
                try
                {
                    objUser = WorkFlowPototype.App_Code.dataConnect.getUserLogin(user);

                    // ---------------- end of switch to local or web api call -------------//

                    if (objUser != null)
                    {
                        if (objUser.id > 0)
                        {
                            Session["user"] = objUser;
                            //if (objUser.accessLevel == 5)
                            //{
                                return RedirectToAction("Index", "Home");
                           // }
                            //else
                            //{
                              //  return RedirectToAction("workQueue", "WorkQueue");
                           // }
                            

                        }
                        else
                        {
                            ViewBag.Message = objUser.message;
                        }
                    }
                    else
                    {
                        ViewBag.Message = "What Happen!";
                        return View("Unexpected Error", new HandleErrorInfo(null, "Login", ""));
                    }
                }
                catch (Exception ex)
                {
                    ViewBag.Title = "UserLogin ActionResult";
                    return View("Error", ex);
                }                
            }
            else
            {
                ViewBag.Message = "";
            }

            return View("UserLogin", "~/Views/Shared/_Layout.cshtml");
            // testing side menu
            //return View("UserLogin", "~/Views/Shared/_sideLayout.cshtml");

        }

        public ActionResult UserLogoff()
        {
            try
            {
                TrustedI10model.client.m_userOBJ user_obj = (TrustedI10model.client.m_userOBJ)Session["user"];
                if (user_obj != null)
                {
                    if (user_obj.id > 0)
                    {   // we are not locking the user at the database level, yet.
                        //TrustedI10DataContext.App_Code.Data.userLogin.userLogoff(user_obj.id, user_obj.databaseName);
                        //userID = Convert.ToInt32(Session["user"].ToString());
                        //TrustedI10DataContext.App_Code.Data.userLogin.userLogoff(userID, Session["BlueSkySailerBeware"].ToString());
                    }
                }
                Session.Clear();
                return RedirectToAction("Index", "Home");
            }
            catch (Exception ex)
            {
                ViewBag.Title = "UserLogoff ActionResult";
                return View("Error", ex);
            }
        }      



    }
}