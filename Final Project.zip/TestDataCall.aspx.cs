﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using TrustedI10DataContext;
using System.Web.Services;
using WorkFlowPototype.Testing;

namespace WorkFlowPototype
{
    public partial class TestDataCall : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //TrustedI10DataContext.App_Code.Model.m_userOBJ objUser = new TrustedI10DataContext.App_Code.Model.m_userOBJ();
            //objUser = TrustedI10DataContext.App_Code.Biz.userLogin.getUserLogin("micky@gmail.com", "cheese123*");

            //TestingSoapClient client = new TestingSoapClient();

            //string result = client.HelloWorld();
            //Label1.Text = result;

            string db = "groupabc";

            TrustedI10model.workflow.m_uploadFile obj = new TrustedI10model.workflow.m_uploadFile();
            obj.facilityID = 1;
            obj.whoUploadID = 2;
            obj.filedate = "7/15/2017";
            obj.filename = "testUploadFromFrontEnd.txt";
            obj.texts = "Doctor long nots........";

            WorkFlowPototype.App_Code.dataConnect.insertUploadFile(obj, db);

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            // re-load
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            // save
            int emrHdId = 1;
            int userID = 1;
            string db = "groupabc";

            TrustedI10model.workflow.m_wholeEMR mrOBJ = new TrustedI10model.workflow.m_wholeEMR();

            TrustedI10model.workflow.m_emrHeader header = new TrustedI10model.workflow.m_emrHeader();
            List<TrustedI10model.workflow.m_codeSelected> dx = new List<TrustedI10model.workflow.m_codeSelected>();
            List<TrustedI10model.workflow.m_codeSelected> li = new List<TrustedI10model.workflow.m_codeSelected>();
            List<TrustedI10model.workflow.m_emrNoteOBJ> notes = new List<TrustedI10model.workflow.m_emrNoteOBJ>();

            TrustedI10model.workflow.m_codeSelected dxOBJ = new TrustedI10model.workflow.m_codeSelected();
            TrustedI10model.workflow.m_codeSelected liOBJ = new TrustedI10model.workflow.m_codeSelected();
            TrustedI10model.workflow.m_emrNoteOBJ noteObj = new TrustedI10model.workflow.m_emrNoteOBJ();

            noteObj.userID = userID;
            noteObj.note = "Testing update.....";
            notes.Add(noteObj);
            mrOBJ.lstNotes = notes;

            // extract from db, will pretend we make changes and call th update
            dx = TrustedI10DataContext.App_Code.Data.workQueue.getEMR_CodeSelected(emrHdId, db, "dx");
            li = TrustedI10DataContext.App_Code.Data.workQueue.getEMR_CodeSelected(emrHdId, db, "li");
            header = TrustedI10DataContext.App_Code.Data.workQueue.getEMR_Header(emrHdId, db);

            // making changes
            // may be we can just pass in just the  one being update...
            // id=0, add
            // id=-1, remove
            // id=-2, update

        }

        protected void Button3_Click(object sender, EventArgs e)
        {

            int emrHdId = 1;
            int facID = 1;
            string db = "groupabc";

            // check the  code
            TrustedI10model.workflow.m_CheckCodeResult obj= WorkFlowPototype.App_Code.dataConnect.getEMResult(emrHdId, facID, db);


        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            // search
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            WorkFlowPototype.App_Code.dataConnect.resetTestData("groupabc");
        }
    }
}