﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WorkFlowPototype.Models
{
    public class Fruits
    {
        public int FruitID { get; set; }
        public string FruitName { get; set; }
        public bool IsCheck { get; set; }
    }
    public class FruitLst
    {
        public List<Fruits> fruits { get; set; }
    }
}