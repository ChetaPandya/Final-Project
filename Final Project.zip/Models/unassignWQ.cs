﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WorkFlowPototype.Models
{
    public class unassignObj
    {
        public bool IsCheck { get; set; }
        public int emrHdID { get; set; }
        public string filename { get; set; }
        public string uploaded_date { get; set; }
        public string whoUploaded { get; set; }
        public string facilityName { get; set; }
        public string status { get; set; }
    }

    public class unassignLst
    {
       public List<unassignObj> wqLst = new List<unassignObj>();
    }
}